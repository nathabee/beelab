// src/components/FarmMgt.tsx
'use client';

import React from "react";
import { useProtectedPage } from "@hooks/useProtectedPage";
import FieldSelection from "@components/FieldSelection";
import ActiveContextCard from "@components/ActiveContextCard";
import FieldEditCard from "@components/FieldEditCard";

import { useAuth } from '@context/AuthContext';



const FarmMgt: React.FC = () => {
  console.log('[FarmMgt] component called');
  useProtectedPage(); // redirects if not logged



  const {  activeField } = useAuth();



  return (
    <>
      <h1>Farm Management</h1>
      <FieldSelection />
      <ActiveContextCard />
      <FieldEditCard field={activeField} />
    </>
  );
};

export default FarmMgt;
