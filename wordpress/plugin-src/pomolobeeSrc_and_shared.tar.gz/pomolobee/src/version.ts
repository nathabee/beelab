export const VERSION='v1.0.11'; export const COMMIT='2969cd3'; export const BUILT_AT='2025-09-22T13:37:59.089Z';
